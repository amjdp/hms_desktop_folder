from django.apps import AppConfig


class HospitalConfig(AppConfig):
    name = 'hospital'
